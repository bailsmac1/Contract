
const express = require('express');
const http = require('http');
const app = express();
app.use(express.static('public'));
const server = http.createServer(app);
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log('Server listening on', PORT));
